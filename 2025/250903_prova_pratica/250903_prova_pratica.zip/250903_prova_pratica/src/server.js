/*
03/09/25
SENAI - Análise e Desenvolvimento de Sistemas
Desenvolvimento de Sistemas
Docente: Ruan
Discente: Jean Douglas Junior

Avaliação Prática

*/

const express = require('express');
const vagasRouter = require('./router/vagasRouter');
const app = express();
app.use(express.json());
// raiz
app.get('/', (_, res) => res.send('API Users OK'));
// rotas de produtos
app.use('/vagas', vagasRouter);
// 404 de rota
app.use((_, res) => res.status(404).json({ erro: 'Rota não encontrada' }));
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API da Loja em http://localhost:${PORT}`));